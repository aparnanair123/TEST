<?php
session_start();
$dbcon =  mysqli_connect('localhost','root','','studentmanagement' );
$base_url   = "http://".$_SERVER['SERVER_NAME']."/interview/haatch";	

function check_login(){
	global $base_url;

 	if($_SESSION['userid'] == ""){
		header("Location: ".$base_url."/logout.php");
		exit;
	}
}
?>

