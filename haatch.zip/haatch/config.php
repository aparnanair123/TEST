<?php
$dbcon =  mysqli_connect('localhost','root','','studentmanagement' );
?>