<?php 
include('config.php');
$errormsg = "";

$selectdata = mysqli_fetch_array(mysqli_query($dbcon,"SELECT * FROM sm_studentdetails WHERE id = '".$_GET['id']."'"));
if(isset($_POST['btnsubmit']) == "Update"){
	
	$checkentry = mysqli_num_rows(mysqli_query($dbcon,"SELECT * FROM sm_studentdetails where  email = '".$_POST['email']."' "));

	if($checkentry ==0 ) {

	$sqlquery= mysqli_query( $dbcon,"UPDATE  sm_studentdetails SET first_name = '".$_POST['firstname']."' , last_name = '".$_POST['lastname']."', email = '".$_POST['email']."', grade = '".$_POST['grade']."', branch ='".$_POST['branch']."', doj ='".$_POST['doj']."' where id =  '".$_GET['id']."'");
	header('Location:student_master.php');

}else{
	$errormsg =  "Entry Already Exists";
}}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Student Management System</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>

		<div class="bg-wrapper">
			<div class="boxcontent">
				<button style= "float:right;" onClick="window.location.href='logout.php'">Logout</button>

					<form action="" id = "formlogin" method = "post">
						<h5>Edit Student Details</h5>
						<?php if(isset($errormsg)){echo '<h4 style = color:red>'.$errormsg.'<h4>'; } ?>

						<div class="form-holder ">
							<input type="text" placeholder="First Name" class="form-control" name = "firstname" value =  "<?php echo $selectdata['first_name'] ?>" required>
						</div>
						<div class="form-holder">
							<input type="text" placeholder="Last Name" class="form-control" style="font-size: 15px;" name = "lastname" value =  "<?php echo $selectdata['last_name']  ?>" required>
						</div>
						<div class="form-holder">
							<input type="email" placeholder="E-mail" class="form-control" style="font-size: 15px;" name = "email" value =  "<?php echo $selectdata['email'] ?>" required>
						</div>
						<div class="form-holder">
							<select class="form-control" style="font-size: 15px;" name = "grade" required>
								<option value = "">Select Grade</option>
								<option value = "Grade1" <?php if($selectdata['grade'] == "Grade1") echo "SELECTED"; ?>>Grade1</option>
								<option value = "Grade2"<?php if($selectdata['grade'] == "Grade2") echo "SELECTED"; ?>>Grade2</option>
								<option value = "Grade3" <?php if($selectdata['grade'] == "Grade3") echo "SELECTED"; ?>>Grade3</option>
							</select>
						</div>
						<div class="form-holder">
							<select class="form-control" style="font-size: 15px;" name = "branch" required>
								<option value = "">Select Branch</option>
								<?php $branchdet =  mysqli_query($dbcon,"SELECT id,branchname FROM sm_branchmaster ORDER BY id");
									while($branchname =  mysqli_fetch_array($branchdet)){
								?>
								<option value =  "<?php echo $branchname['id'];  ?>"<?php if($branchname['id'] == $selectdata['branch']) echo "SELECTED"; ?>> <?php echo $branchname['branchname'];?> </option>
									<?php } ?>
							</select>
						</div>
							
						<div class="form-holder">
							<input type="date" placeholder="Date of Join" class="form-control" style="font-size: 15px;" name = "doj" value = "<?php echo $selectdata['doj'];?>" required>
						</div>
						
						<div class="form-login">
							<input type="submit" value="Update" id="btnsubmit" name="btnsubmit" class = "button" >
						</div>
					</form>
			</div>
		</div>


	</body>
</html>