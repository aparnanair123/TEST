<?php 
include('config.php');
$errormsg = "";

if(isset($_POST['btnlogin']) == "Login"){

$username =  $_POST['username'];
$password  = md5($_POST['userpass']);
$sqlresult =  mysqli_num_rows(mysqli_query($dbcon,"SELECT * FROM sm_logindetails WHERE user_name =  '".$username."'and user_password =  '".$password."' "));
if($sqlresult == 1){
	header('Location:student_master.php');
}else{
	$errormsg =  "Incorrect username or password";
}

}

?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Student Management System</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>

		<div class="outer">
		
			<div class="inner">
			
			
				<form action="" id = "formlogin" method = "post">
					<h3>Login</h3>
					<?php if(isset($errormsg)){echo '<h4 style = color:green>'.$errormsg.'<h4>'; } ?>

					<div class="form-holder ">
						<input type="text" placeholder="Username/E-mail" class="form-control" name = "username"  required>
					</div>
					<div class="form-holder">
						<input type="password" placeholder="Password" class="form-control" style="font-size: 15px;" name = "userpass" required>
					</div>
					
					<div class="form-login">
						<input type="submit" value="Login" id="btnlogin" name="btnlogin" class = "button" >

					</div>
				</form>
			</div>
		</div>


	</body>
</html>