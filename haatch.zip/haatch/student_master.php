<?php 
include('config.php');
$whercond = "";
$mail =  "";
$branch = "";
if(isset($_POST['btnsubmit']) == "Search") { 
$mail 	   = trim($_POST['email']);
$branch    = trim($_POST['branch']);

if($mail!="")
	$whercond.=" and email = '".$mail."'";

if($branch!="")
	$whercond.=" and branch = '".$branch."'";

}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Student Management System</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>

		<div class="bg-wrapper">

			<div class="boxcontent">
								<button style= "float:right;" onClick="window.location.href='logout.php'">Logout</button>

					<h3> Student Details</h3>

				<form action="" id = "formlogin" method = "post">
					<div class="form-holder">
							<select class="form-control" style="font-size: 15px;" name = "branch" >
								<option value = "">Select Branch</option>
								<?php $branchdet =  mysqli_query($dbcon,"SELECT id,branchname FROM sm_branchmaster ORDER BY id");
									while($branchname =  mysqli_fetch_array($branchdet)){
								?>
								<option value =  "<?php echo $branchname['id'];  ?>"> <?php echo $branchname['branchname'];?> </option>
									<?php } ?>
							</select>
						</div>
					<div class="form-holder">
						<input type="text" placeholder="Enter Email" class="form-control" style="font-size: 15px;" name = "email" >
					</div>	
					<div class="form-login">
							<input type="submit" value="Search" id="btnsubmit" name="btnsubmit" class = "button" >
						</div>
				</form>						
			
	<button  type="button" class =  "button" style= "float:right;margin-bottom:15px;" onclick="window.location.href='add_student.php'">ADD NEW</button>
	<button  type="button" class =  "button" style= "float:right;margin-bottom:15px;" onclick="window.location.href='student_master.php'">REFRESH</button>

	<br><br>	
	<table id="example" class="table  table-striped" >
					<thead>
						<tr>
							<th>S no</th>
							<th> First Name</th>
							<th>Last Name</th>
							<th>Email</th>
							<th>Grade</th>
							<th>Branch</th>
							<th>Date of Join</th>
							<th>Edit</th>
							</tr>
					</thead>
				<tbody>
				<?php
				$i = 1;
				$selectstudentdata = mysqli_query($dbcon,"SELECT  id,first_name, last_name, email, grade, branch, doj FROM sm_studentdetails where user_type ='S' ".$whercond."  ORDER BY id");
						while($row = mysqli_fetch_array($selectstudentdata)){
							$branchname =  mysqli_fetch_array(mysqli_query($dbcon,"SELECT branchname FROM sm_branchmaster WHERE id = '".$row['branch']."'"));
				?> 
				
				<tr>
				<td><?php echo $i;  ?></td>
				<td><?php echo  $row['first_name'];?></td>
				<td><?php echo $row['last_name'];?></td>
				<td><?php echo $row['email'];?></td>
				<td><?php echo $row['grade'];?></td>
				<td><?php echo $branchname['branchname'];?></td>
				<td><?php echo $row['doj'];?></td>
				<td>		
				<a href =  "edit_student.php?id=<?php echo $row['id']; ?>" style="cursor: pointer;" data-toggle="tooltip" title="Delete!"><img height="18px" src="images/edit.png" ></a>
				</td>
				</tr>
				<?php $i++;} ?>
				
				</tbody>
				</table>
					</form>
			</div>
		</div>


	</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css"/>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/jquery.dataTables.min.js"></script>
  <script>
  $('#example').dataTable( {
  "searching": false
} );
</script>


</body>
<script>
</html>