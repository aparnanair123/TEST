<?php 
include('config.php');
$errormsg = "";

if(isset($_POST['btnsubmit']) == "Add"){
	$checkentry = mysqli_num_rows(mysqli_query($dbcon,"SELECT * FROM sm_studentdetails where  email = '".$_POST['email']."' "));

	if($checkentry ==0 ) {

	$sqlquery= mysqli_query( $dbcon,"INSERT INTO sm_studentdetails( first_name, last_name, email, grade, branch, doj, datetime, user_type, ip_address) VALUES
	('".$_POST['firstname']."','".$_POST['lastname']."','".$_POST['email']."','".$_POST['grade']."','".$_POST['branch']."','".$_POST['doj']."',now(),'S','".$_SERVER["REMOTE_ADDR"]."')");
			header('Location:student_master.php');

}else{
	$errormsg =  "Entry Already Exists";
}}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Student Management System</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>


	<body>
	
		<div class="bg-wrapper">

			<div class="boxcontent">

				<button style= "float:right;" onClick="window.location.href='logout.php'">Logout</button>


					<form action="" id = "formlogin" method = "post">
						<h5>Add Student Details</h5>
							<?php if(isset($errormsg)){echo '<h4 style = color:red>'.$errormsg.'<h4>'; } ?>

						<div class="form-holder ">
							<input type="text" placeholder="First Name" class="form-control" name = "firstname" required>
						</div>
						<div class="form-holder">
							<input type="text" placeholder="Last Name" class="form-control" style="font-size: 15px;" name = "lastname" required>
						</div>
						<div class="form-holder">
							<input type="email" placeholder="E-mail" class="form-control" style="font-size: 15px;" name = "email" required>
						</div>
						<div class="form-holder">
							<select class="form-control" style="font-size: 15px;" name = "grade" required>
								<option value = "">Select Grade</option>
								<option value = "Grade1">Grade1</option>
								<option value = "Grade2">Grade2</option>
								<option value = "Grade3">Grade3</option>
							</select>
						</div>
						<div class="form-holder">
							<select class="form-control" style="font-size: 15px;" name = "branch" required>
								<option value = "">Select Branch</option>
								<?php $branchdet =  mysqli_query($dbcon,"SELECT id,branchname FROM sm_branchmaster ORDER BY id");
									while($branchname =  mysqli_fetch_array($branchdet)){
								?>
								<option value =  "<?php echo $branchname['id'];  ?>"> <?php echo $branchname['branchname'];?> </option>
									<?php } ?>
							</select>
						</div>
							
						<div class="form-holder">
							<input type="date" placeholder="Date of Join" class="form-control" style="font-size: 15px;" name = "doj" required>
						</div>
						
						<div class="form-login">
							<input type="submit" value="Add" id="btnsubmit" name="btnsubmit" class = "button" >
						</div>
					</form>
			</div>
		</div>


	</body>
</html>